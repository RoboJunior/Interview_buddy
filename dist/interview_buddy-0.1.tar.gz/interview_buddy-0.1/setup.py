from setuptools import setup, find_packages

setup(
    name='interview_buddy',
    version='0.1',
    packages=find_packages(),
    author='R Jeyaraman',
    author_email='jeyaramanjr7@gmail.com',
    description='This package is made for beginners who are appearing for interview preparation and to crack coding interviews',
)